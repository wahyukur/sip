<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateKegiatansTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('kegiatans', function (Blueprint $table) {
            $table->increments('id_kegiatan');
            $table->unsignedInteger('id_agenda');
            $table->unsignedInteger('id_tamu');
            $table->string('gambar_kegiatan1');
            $table->string('gambar_kegiatan2');
            $table->string('pmt1');
            $table->string('pmt2');
            $table->string('tidak_hadir');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('kegiatans');
    }
}
