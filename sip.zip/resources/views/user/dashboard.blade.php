@extends('layouts.base')

@section('content')
<h1>User</h1>
@endsection
