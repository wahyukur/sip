<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Timbang extends Model
{
    protected $table = 'timbangs';
    protected $primaryKey = 'id_timbang';
}
