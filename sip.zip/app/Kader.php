<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Kader extends Model
{
    protected $table = 'kaders';
    protected $primaryKey = 'id_kader';
}
