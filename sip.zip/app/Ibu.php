<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ibu extends Model
{
    protected $table = 'ibus';
    protected $primaryKey = 'id_ibu';
}
