<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VitA extends Model
{
    protected $table = 'vit_as';
    protected $primaryKey = 'id_vitA';
}
