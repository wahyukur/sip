<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class IbuHamil extends Model
{
    protected $table = 'ibu_hamils';
    protected $primaryKey = 'id_bumil';
}
