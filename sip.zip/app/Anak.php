<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Anak extends Model
{
    //
    protected $table = 'anaks';
    protected $primaryKey = 'id_anak';
}
