<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// route auth login dan register
// Auth::routes();

// Route::middleware(['web', 'auth'])->group(function (){
	
// 	Route::get('/', 'DashboardController@index');

// 	Route::middleware(['admin'])->group(function(){
// 		Route::get('admin', function (){
// 			return view('admin.dashboard');
// 		});
// 		Route::resource('ibu', 'IbuController');
// 		Route::resource('anak', 'AnakController');
// 		Route::resource('ibuhamil', 'IbuHamilController');
// 		Route::resource('kader', 'KaderController');
// 		Route::resource('pengguna', 'PenggunaController');
// 		Route::resource('agenda', 'AgendaController');
// 		Route::resource('bukutamu', 'BukuTamuController');
// 		Route::resource('timbang', 'TimbangController');
// 		Route::resource('vitA', 'VitAController');
// 		Route::resource('kegiatan', 'KegiatanController');
// 		Route::resource('jenisimunisasi', 'JenisImunisasiController');
// 	});

// 	Route::middleware(['user'])->group(function(){
// 		Route::get('user', function (){
// 			return view('user.dashboard');
// 		});
// 	});
// });


Route::middleware(['guest'])->group(function(){
	Route::get('/', 'AuthController@getLogin')->name('login');
	Route::post('postlogin', 'AuthController@postLogin')->name('postlogin');
});

Route::middleware(['web', 'auth'])->group(function(){

	Route::middleware(['admin'])->group(function(){
		Route::get('admin', 'DashboardController@index')->name('admin');
		Route::resource('ibu', 'IbuController');
		Route::resource('anak', 'AnakController');
		Route::resource('ibuhamil', 'IbuHamilController');
		Route::resource('kader', 'KaderController');
		Route::resource('pengguna', 'PenggunaController');
		Route::resource('agenda', 'AgendaController');
		Route::resource('bukutamu', 'BukuTamuController');
		Route::resource('timbang', 'TimbangController');
		Route::resource('vitA', 'VitAController');
		Route::resource('kegiatan', 'KegiatanController');
		Route::resource('jenisimunisasi', 'JenisImunisasiController');
	});

	Route::middleware(['user'])->group(function(){
		Route::get('user', function (){
			return view('user.dashboard');
		})->name('user');
	});

	Route::get('logout', 'DashboardController@getLogout')->name('logout');
});